PrintYour2AR-9 

-Print Lower receiver with magwell on bed. .2mm layer height is recommended.
-Print remaining components at .1mm layer height, flat sides down.
-Pin holes will be tight at first, do not drill them out unless absolutely neccessary.
-Follow PY2AR-15 Instructions for Rear Brace installation.
-BHO Front Lever magazine catch tab will need to be modified depending on magazines used,
 some filing/ bending may be needed.
-Thread Magazine Release Button onto the magazine catch prior to installation to create threads more easily.
- An Assist spring may be needed under the BHO Rear Lever, I used
 a trimmed BIC lighter spring(under the button, not the flint)